import lcdF7D

lcdF7D.init()

for i in range(lcdF7D.get_x_size()):
    lcdF7D.set_text_color(255, 0, 0, i*256//lcdF7D.get_x_size())
    lcdF7D.draw_Vline(i, 0, lcdF7D.get_y_size())

lcdF7D.set_font(12)
lcdF7D.set_text_color(255,255,255,0)
lcdF7D.display_string_at(0,0,'Hello',0)
lcdF7D.set_font(16)
lcdF7D.set_text_color(255,255,255,255)
lcdF7D.display_string_at(0,20,'Hello',0)
lcdF7D.set_font(24)
lcdF7D.set_text_color(255,255,128,0)
lcdF7D.display_string_at(0,50,'Hello',0)
